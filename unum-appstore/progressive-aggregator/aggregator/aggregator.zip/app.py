"""
Aggregator - Processes inputs incrementally as they arrive.

This is where Future-Based mode shines:
- In Classic mode: waits for ALL inputs via DynamoDB polling
- In Future-Based mode: processes each input as its Future resolves
"""
import time
import json
import os
import boto3

# SQS for completion signaling
SQS_QUEUE_URL = os.environ.get('SQS_RESULT_QUEUE', 
    'https://sqs.eu-west-1.amazonaws.com/528757807812/progressive-aggregator-results')
sqs_client = boto3.client('sqs', region_name='eu-west-1')


def lambda_handler(event, context):
    """
    Aggregate data from multiple sources.
    
    The key insight: we process EACH input as it arrives,
    not waiting for all inputs before starting work.
    
    NOTE: User code is IDENTICAL for all modes (Classic, Eager, Future-Based).
    The framework handles input resolution transparently via LazyInputList
    or AsyncFutureInputList which behave exactly like regular Python lists.
    """
    start_time = time.time()
    
    # In Unum, 'event' can be:
    # - A regular list (Classic mode)
    # - A LazyInputList (Eager mode) 
    # - AsyncFutureInputList (Future-Based mode)
    # ALL support transparent iteration - user code doesn't need to change!
    inputs = event
    
    results = []
    total_sum = 0
    processing_log = []
    
    # Get mode from environment for logging
    eager_mode = os.environ.get('EAGER', 'false').lower() in ('true', '1', 'yes')
    future_mode = os.environ.get('UNUM_FUTURE_BASED', 'false').lower() in ('true', '1', 'yes')
    mode = 'FUTURE_BASED' if (eager_mode and future_mode) else ('EAGER' if eager_mode else 'CLASSIC')
    
    print(f'[AGGREGATOR] Mode: {mode}, Input type: {type(inputs).__name__}')
    
    for i, source_data in enumerate(inputs):
        # Record when we received this input
        # In Future-Based mode, this is when the future resolved
        receive_time = time.time()
        
        # Process this input - source_data IS the actual dict (resolved by framework)
        # User code is IDENTICAL regardless of mode!
        source_sum = source_data.get('sum', 0) if isinstance(source_data, dict) else 0
        source_id = source_data.get('source_id', i) if isinstance(source_data, dict) else i
        
        total_sum += source_sum
        
        processing_log.append({
            "source_id": source_id,
            "received_at_ms": int((receive_time - start_time) * 1000),
            "value": source_sum
        })
        
        results.append({
            "source_id": source_id,
            "sum": source_sum,
            "processed_order": i + 1
        })
    
    end_time = time.time()
    
    result = {
        "total_sum": total_sum,
        "sources_processed": len(results),  # Use len(results) instead of len(inputs)
        "processing_log": processing_log,
        "results": results,
        "aggregator_duration_ms": int((end_time - start_time) * 1000),
        "mode": mode,
        "timestamp": end_time
    }
    
    # Send completion signal to SQS for benchmarking
    try:
        sqs_client.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(result)
        )
        print(f'[AGGREGATOR] Sent result to SQS: total_sum={total_sum}, duration={result["aggregator_duration_ms"]}ms')
    except Exception as e:
        print(f'[AGGREGATOR] Failed to send to SQS: {e}')
    
    return result


if __name__ == '__main__':
    # Test with mock inputs
    mock_inputs = [
        {"source_id": 1, "sum": 100},
        {"source_id": 2, "sum": 200},
        {"source_id": 3, "sum": 300},
    ]
    result = lambda_handler(mock_inputs, None)
    print(json.dumps(result, indent=2))
