"""DAGL Runtime Layer - FaaS Invocation Backend

Reads function ARN mapping from DAGL_FUNCTION_MAP env var instead of a file.
"""

import json
import os


class InvocationBackend(object):
    subclasses = {}

    @classmethod
    def add_backend(cls, platform):
        def wrapper(subclass):
            cls.subclasses[platform] = subclass
            return subclass
        return wrapper

    @classmethod
    def create(cls, platform):
        if platform not in cls.subclasses:
            raise ValueError(f'DAGL runtime does not support platform: {platform}')
        return cls.subclasses[platform]()


@InvocationBackend.add_backend('aws')
class AWSLambdaBackend(InvocationBackend):

    def __init__(self):
        import boto3
        self.lambda_client = boto3.client("lambda")
        
        # Read function mapping from env var (set by dagl deploy)
        map_str = os.environ.get('DAGL_FUNCTION_MAP', '{}')
        self.mapping = json.loads(map_str)

    def invoke(self, function, data):
        return self._http_invoke_async(self.mapping[function], data)

    def _http_invoke_async(self, function_arn, data):
        """Invoke a Lambda function asynchronously (fire-and-forget)."""
        response = self.lambda_client.invoke(
            FunctionName=function_arn,
            InvocationType='Event',
            LogType='None',
            Payload=json.dumps(data),
        )
        response['Payload'].read()
        return


@InvocationBackend.add_backend('gcloud')
class GCloudFunctionBackend(InvocationBackend):

    def __init__(self):
        from google.cloud import pubsub_v1
        self.pubsub = pubsub_v1.PublisherClient()
        
        # Read function mapping from env var
        map_str = os.environ.get('DAGL_FUNCTION_MAP', '{}')
        self.mapping = json.loads(map_str)

    def invoke(self, function, data):
        self._pubsub_invoke(self.mapping[function], data)

    def _pubsub_invoke(self, topic, data):
        try:
            self.pubsub.publish(topic, json.dumps(data).encode('utf-8'))
        except Exception as e:
            raise e


@InvocationBackend.add_backend('fake')
class FakeFaaSBackend(InvocationBackend):

    def invoke(self, function, data):
        print(f'[DAGL FaaS: fake] Invoking {function}')
        print(f'[DAGL FaaS: fake] Payload: {data}')
        return data
